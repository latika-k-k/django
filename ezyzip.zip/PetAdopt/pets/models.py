from django.db import models

class Pet(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    breed = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='pet_images/', blank=True, null=True)
    is_adopted = models.BooleanField(default=False)

    def __str__(self):
        return self.name
