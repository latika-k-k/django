from django.shortcuts import render, get_object_or_404,redirect
from .models import Pet
from .forms import PetForm

# View to list all pets

def pet_list(request):
    pets = Pet.objects.all()  # Get all pets
    return render(request, 'pets/pet_list.html', {'pets': pets})

# View to show pet details

def pet_detail(request, pet_id):
    pet = get_object_or_404(Pet, pk=pet_id)  # Get pet by id or return 404 if not found
    return render(request, 'pets/pet_detail.html', {'pet': pet})

def pet_create(request):
    if request.method == 'POST':
        form = PetForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('pet_list')  # Redirect to pet list after saving
    else:
        form = PetForm()
    return render(request, 'pets/pet_form.html', {'form': form})

# View to update an existing pet

def pet_update(request, pet_id):
    pet = get_object_or_404(Pet, pk=pet_id)
    if request.method == 'POST':
        form = PetForm(request.POST, request.FILES, instance=pet)
        if form.is_valid():
            form.save()
            return redirect('pet_list')
    else:
        form = PetForm(instance=pet)
    return render(request, 'pets/pet_form.html', {'form': form})

# View to delete a pet

def pet_delete(request, pet_id):
    pet = get_object_or_404(Pet, pk=pet_id)
    if request.method == 'POST':
        pet.delete()
        return redirect('pet_list')  # Redirect to pet list after deletion
    return render(request, 'pets/pet_confirm_delete.html', {'pet': pet})

