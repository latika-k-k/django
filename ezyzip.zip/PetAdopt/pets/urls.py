from django.urls import path
from . import views

urlpatterns = [
    path('', views.pet_list, name='pet_list'),
    path('pet/<int:pet_id>/', views.pet_detail, name='pet_detail'),
    path('pet/create/', views.pet_create, name='pet_create'),
    path('pet/<int:pet_id>/update/', views.pet_update, name='pet_update'),
    path('pet/<int:pet_id>/delete/', views.pet_delete, name='pet_delete'),
]
